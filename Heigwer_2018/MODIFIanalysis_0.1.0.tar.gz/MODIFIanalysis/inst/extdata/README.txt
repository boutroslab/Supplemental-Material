all data from these gene-drug-interaction screens were analysed together:

see scripts at:

1.	all_in_one_v1.3.clust.analyze.pl		#automated data handling pipeline to analyse all suitable images within a set of subdirectories
2.	image_analysis_ERC.v3.R					#image analysis pipeline input: 3 channel image set for one field of view; output: feature vectors for every single cell 
3.	extract_data.pl							#script to extract barcode meta-data from filenames
4.	collect_RData_files.R					#script to collect all single cell data tables as trimmed mean vectors in one big dataframe

all data from these gene-gene-drug-interaction screens were analysed together:

see scripts at:

1.	all_in_one_v1.6.clust.analyze.pl		#automated data handling pipeline to analyse all suitable images within a set of subdirectories
2.	image_analysis_ERC.v6.R					#image analysis pipeline input: 3 channel image set for one field of view; output: feature vectors for every single cell 
3.	extract_data.pl							#script to extract barcode meta-data from filenames
4.	collect_RData_files.R					#script to collect all single cell data tables as trimmed mean vectors in one big dataframe
