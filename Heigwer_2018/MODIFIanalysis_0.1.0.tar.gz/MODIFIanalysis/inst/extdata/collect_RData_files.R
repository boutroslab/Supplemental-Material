args=commandArgs(trailingOnly = TRUE)
options("scipen"=100,warn=-1)
dir=args[1];

print("I am starting")
total.df=list()
for(indir in list.dirs(path = dir, full.names = TRUE, recursive = FALSE) ){
  print(indir)
  filelist=list.files(indir,pattern =".RData",full.names = TRUE)
  per_plate=list()
  for(i in 1:24){
    for(j in c("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P")){
      files=filelist[grep(paste0("_",j,i,"_",".*RData"),filelist,perl = TRUE)]
          if(length(files)==4){
            data.list=list()
            for(file in files){
              load(file)  
              data.list[[file]]=cell_features
            } 
            daten=do.call("rbind.data.frame",data.list)
            columns=dim(daten)[2]
            namen=names(daten)
            cell_number=nrow(daten)
            row.names(daten)=seq(1:dim(daten)[1])         
            daten=apply(daten, 2, function(x){
                                                c(
                                                  mean(x,trim=0.01, na.rm=TRUE),
                                                  sd(x,na.rm=TRUE)
                                                  )
                          }
            )
                       
    	      wellname=paste0(j,i)
            barcode=sub(pattern = paste0("_",j,i,"_\\d+_single_cell.RData"),replacement ="" ,x = file,perl=TRUE)
            barcode=sub(pattern = paste0(".*/"),replacement ="" ,x = barcode,perl=TRUE)
            cur.df=data.frame(t(c(cell_number,daten[1,],daten[2,])))
            names(cur.df)=c("cell_number",paste0(namen,".tmean"),paste0(namen,".sd")) 
            cur.df$well=wellname
            cur.df$plate=sub("ERC.+HD3A_([0-9]+?)_.+","\\1",barcode,perl=TRUE)
            cur.df$screenID=sub("ERC.+HD3A_[0-9]+?_(.+?)","\\1",barcode,perl=TRUE)
    	      per_plate[[wellname]]=cur.df
        }else{
        	print(paste(i,j,"is not complete in \n",indir,"\n"))     
        }
      }
    }
  total.df[[indir]]<-do.call("rbind.data.frame",per_plate)
  print(paste(indir,"done")) 
}
total.df=do.call("rbind.data.frame",total.df)
row.names(total.df)=paste(sep="_",total.df$screenID,total.df$plate,total.df$well)
save(total.df,file=paste0(args[1],"/",args[2]))