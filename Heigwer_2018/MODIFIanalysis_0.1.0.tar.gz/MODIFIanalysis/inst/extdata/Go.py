import sys
import re
import os
import zipfile

def openFile(text):
    #open the file in the first argument and return all its lines
    Input = []
    with open(text, 'Ur') as f:
        while True:
            line = f.readline()
            if not line: break
            Input.append(line.rstrip('\n'))
    return Input

lines = openFile("gene_association.fb")
lines2 = openFile("result_complete.txt")

data = []
data.append([])
data.append([])
data.append([])
data.append([])
data.append([])
for line in lines:
	temp = line.split('\t')
	if len(temp) == 1:
		continue
	data[0].append(temp[1])
	data[1].append(temp[4])
	data[2].append(temp[6])
	#if len(data[0]) == 1000:
	#	break
	
anno = []
anno.append([])
anno.append([])
for line in lines2:
	temp = line.split('\t')
	if len(temp) == 1:
		continue
	anno[0].append(temp[2])
	anno[1].append(temp[3])
	#if len(anno[0]) == 1000:
	#	break

#remove all elements, that don't appear in the large list from fb
rm = [True if name in anno[0] else False for name in data[0]]
rmi = [i for i, elem in enumerate(rm) if elem]
data[0] = [data[0][i] for i in rmi]
data[1] = [data[1][i] for i in rmi]
data[2] = [data[2][i] for i in rmi]

data[3] = ["NA"] * len(data[0])
for i in range(0,len(anno[0])):
	for j in range(0, len(data[0])):
		if anno[0][i] == data[0][j]:
			data[3][j] = anno[1][i]
	#print "done with i= " + str(i)

values = {
	'IGI':9,
	'IDA':8,
	'IPI':7,
	'IMP':6,
	'IEP':6,
	'RCA':5,
	'TAS':4,
	'ISS':4,
	'IC':3,
	'NAS':2,
	'ND':1,
	'IEA':1,
	'IKR':3,
	'IBA':1,
	'IRD':1,
	'ISM':2,
	'IGC':2,
	'ISO':2,
	'ISA':2
}
count = dict.fromkeys(data[0],0)

for fbgn in set(data[0]):
	for i in range(0,len(data[0])):
		if fbgn == data[0][i]: #and data[2][i] in values
			count[fbgn] += values[data[2][i]]

with open("fbgn_knowledge.txt", 'w') as f:
	f.write("fbgn\tgo_sum\n")
	for ele1, ele2 in count.items():
		f.write(str(ele1 + "\t" + str(ele2) + "\n"))
