#!/usr/bin/perl
use strict;
use warnings;
use Parallel::ForkManager;
use Sys::Info;
use Sys::Info::Constants qw( :device_cpu );
use Capture::Tiny ':all';
use File::Find;

my $infolder="/data/raw_data/".$ARGV[0];
my $totalplatenum=$ARGV[1];

my $curplatenumber=0;
while ($curplatenumber<$totalplatenum) {
	opendir(my $bigindir, $infolder);
	print $infolder."\n";
	FORITER: foreach my $subfolder (sort readdir($bigindir)){
		if (-d $infolder."/".$subfolder
			&& !($subfolder=~m/^\./)
		    ) 
		{	
			$infolder=~m/.*\/([^\/]+)\/([^\/]+\/)$/;
			my $bigout="/data/results/$1"."_"."$2";
			if ( !(-d $bigout)){
				system('mkdir '.$bigout);
			}		
			my $outfolder=$bigout.$subfolder;
			if (!(-d $outfolder)) {
				system('mkdir '.$outfolder);				
				print $subfolder."\n";
				start_off_image_analysis ("/data/scripts/genome_wide_image_analysis/image_analysis_ERC.v6.R",$infolder."/".$subfolder,$outfolder,384,"DAPI.tif","Cy3.tif","FITC.tif",40);
				$curplatenumber++;
			}else{
				print $subfolder."\n";
				start_off_image_analysis ("/data/scripts/genome_wide_image_analysis/image_analysis_ERC.v6.R",$infolder."/".$subfolder,$outfolder,384,"DAPI.tif","Cy3.tif","FITC.tif",40);
				$curplatenumber++;
			}
		}else{
				next FORITER;
			}	
	}
	sleep 1;
	closedir($bigindir);
}

sub wanted {
	if($_=~m/(.+)\)\.tif/){
		my $newname=$1;
		$newname=~s/\W//g;
		$newname=~s/^_//g;
		$newname=~s/fld/_/g;
		$newname=~s/wv/_/g;
		$newname=~s/DAPIDAPI/DAPI/g;
		$newname=~s/Cy3Cy3/Cy3/g;
		$newname=~s/Cy5Cy5/Cy5/g;
		$newname=~s/FITCFITC/FITC/g;
		$newname=~s/0(\d)/$1/g;
		$File::Find::dir=~s/.+\/(\S+)_.+$/$1/g;
		if (!(-e $File::Find::dir."_$newname.tif") && !($_=~m/$File::Find::dir/)) {
			rename($_,$File::Find::dir."_$newname.tif");
		}
	}
}

#########################################################################################
#name:      start image analysis
#function:  closes an browser readable svg in a given file if closed already than unclose
#input:     (path/to/filename string) 
#output:    a closed or open svg
#########################################################################################
sub start_off_image_analysis {
	my $path_to_script=$_[0];
	my $input_folder=my $barcode= $_[1];
	$barcode=~s/.+\/(\S+)_.+$/$1/g;
	my $output_folder=$_[2];
	my $format=$_[3];
	my $nuclei_scheme=$_[4];	#fld1wvDAPIDAPI.tif
	my $body_scheme=$_[5];		#fld1wvCy3Cy3.tif
	my $extra_scheme=$_[6];	
	my $tilesize=$_[7];		
	my %Q=();
	my $start = time;
	
	foreach my $letter ("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"){		
		foreach my $number (1..24){
			foreach my $field (1..4){
				my @temp=($letter,$number,$field);
				$Q{$letter.$number."_".$field} = \@temp;
			}
		}
	}
	if (! -e $output_folder."/total.html") {
		system('echo \'perl /data/scripts/genome_wide_image_analysis/waiter.quick.pl '.$barcode.' '.$output_folder.' '.$tilesize.' '.$format.'\' | qsub -l walltime=24:00:00 ');
	}	
	my %smQ;
	my $test=0;
	my $counter=0;
	my $test_injob=0;
	my $queue_length=0;
	print "I am before Queing\n";
		QITER: while(%Q){
				find(\&wanted,$input_folder);
				$counter=0;
				CHECKITER: foreach my $key (keys(%Q)){
					my $letter=@{$Q{$key}}[0];
					my $number=@{$Q{$key}}[1];
					my $field=@{$Q{$key}}[2];					
					if(	(-e $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$nuclei_scheme) 
						&& (-e $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$body_scheme) 
						&& (-e $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$extra_scheme)
						&& !(-z $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$nuclei_scheme) 
						&& !(-z $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$body_scheme) 
						&& !(-z $input_folder."/".$barcode."_".$letter.$number."_".$field."_".$extra_scheme)						
					){
						if(!(-e $output_folder."/".$barcode."_".$letter.$number."_".$field."_single_cell.RData")) {
							$queue_length=capture_stdout {system("qstat -B | grep b ")};					
							$queue_length=~s/\S+\s+\S+\s+\S+\s+(\d+).*$/$1/;
							#print $output_folder."/".$barcode."_".$letter.$number."_".$field."_single_cell.RData\n";
							if ($queue_length< 30) {
								$smQ{$key}=$Q{$key};						
								$test++;
								$counter++;
								if (scalar(keys(%smQ)) >= 16) {								
									my $cmd_start='/usr/bin/R -f '.$path_to_script.' --slave --args';
									my $filename="";
									foreach my $smkey (keys(%smQ)){
										delete $Q{$smkey};
										$filename=$filename." ".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$nuclei_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$body_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$extra_scheme;
									$test_injob++;
									}
									my $cmd_tail=$output_folder;
									system('echo "'.$cmd_start.$filename.' '.$cmd_tail.'" | qsub -l walltime=4:00:00 ');
									sleep 1;
									%smQ=();
									next QITER;										
								}elsif(scalar(keys(%Q)) == scalar(keys(%smQ))){
									my $cmd_start='/usr/bin/R -f '.$path_to_script.' --slave --args';
									my $filename="";
									foreach my $smkey (keys(%smQ)){
										delete $Q{$smkey};
										$filename=$filename." ".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$nuclei_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$body_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$extra_scheme;
									$test_injob++;
									}
									my $cmd_tail=$output_folder;
									system('echo "'.$cmd_start.$filename.' '.$cmd_tail.'" | qsub -l walltime=4:00:00 ');
									sleep 1;
									%smQ=();
									next QITER;
								}else{
									next CHECKITER;
								}
								
							}else{
								next CHECKITER;
							}
						}else{
							delete $Q{$key};
						}						
						
					}else{
						
					}
				}
			}
		print "I am after Queing\n";
		if ( scalar(keys(%smQ)) > 0) {
			#do the raw analysis either with R ,CP, or Hcell
			my $cmd_start='/usr/bin/R -f '.$path_to_script.' --slave --args';
			my $filename="";
			foreach my $smkey (keys(%smQ)){
				$filename=$filename." ".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$nuclei_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$body_scheme."::".$input_folder.'/'.$barcode."_".@{$smQ{$smkey}}[0].@{$smQ{$smkey}}[1]."_".@{$smQ{$smkey}}[2]."_".$extra_scheme;
			$test_injob++;
			}
			my $cmd_tail=$output_folder;
			system('echo "'.$cmd_start.$filename.' '.$cmd_tail.'" | qsub -l walltime=4:00:00 ');
		}
}
		

