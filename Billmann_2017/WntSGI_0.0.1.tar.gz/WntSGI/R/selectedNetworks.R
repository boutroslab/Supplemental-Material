
## Function for subnetwork of Wnt signaling core components
wntCoreNw <- function(sn, snl, snCol, lo, geneticBackground, corSepGI,
                      thresh=0.35, labCol="white", vsize=18) {
  
  tg = rep(sn, times = length(sn))
  qg = rep(sn, each = length(sn))
  
  nw.par <- par(mfrow=c(1, length(geneticBackground)))
  
  for(matrixDim in 1:length(geneticBackground)) {
    snNW = corSepGI[sn,sn,matrixDim]
    dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
    snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
    snNW = snNW[which(snNW[,3] > thresh | snNW[,3] < -thresh),]
    snNW = snNW[which(snNW[,3] < 1),]
    snNW = snNW[order(snNW[,3]),]
    snNW = snNW[seq(2,dim(snNW)[1], by=2),]
    snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
    
    g = graph.empty(directed = FALSE)
    g = add.vertices(g, nv=length(sn))
    V(g)$name = sn
    V(g)$color = snCol
    V(g)$frame.color = snCol
    V(g)$size = vsize
    V(g)$label.cex = 0.9
    V(g)$label.color = labCol
    
    te = cbind(snNW[,1],snNW[,2])
    te = t(te)
    dim(te) = c(length(te),1)
    g = add.edges(g, te, weight = snNW[,3], width = (snNW[,3]-thresh)*2.5)
    E(g)$color <-  ifelse(E(g)$weight > 0, "#2680ff", "red")
    E(g)$lty <- 1
    
    plot(g, layout=lo, main=geneticBackground[matrixDim], sub=paste("Threshold: <", -thresh, "or >", thresh))
  }
  par(nw.par)
}

## Function for across-state subnetwork of Wnt signaling core components
wntCoreNwBetween <- function(sn, snl, snCol, lod, from, to, corAcross,
                             thresh=0.5, labCol="white", vsize=18) {
  
  tg = rep(sn, times = length(sn))
  qg = paste("to",rep(sn, each = length(sn)))
  
  snNW = corAcross[sn,sn,from,to]
  snNW[upper.tri(snNW)] <- NA
  dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
  snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
  snNW = snNW[which(snNW[,3] > thresh | snNW[,3] < -thresh),]
  
  snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
  
  g = graph.empty(directed = FALSE)
  g = add.vertices(g, nv=length(sn)*2)
  V(g)$name = c(sn, paste("to",sn))
  V(g)$color = snCol
  V(g)$frame.color = snCol
  V(g)$size = vsize
  V(g)$label.cex = 0.9
  V(g)$label.color = labCol
  
  te = cbind(snNW[,1],snNW[,2])
  te = t(te)
  dim(te) = c(length(te),1)
  g = add.edges(g, te, weight = snNW[,3], width = (snNW[,3]-thresh+0.2)*1.5)
  E(g)$color <-  ifelse(E(g)$weight > 0, "#2680ff", "red")
  E(g)$lty <- 2
  
  plot(g, layout=lod, main=paste(from,"to",to),
       sub=paste("Threshold: <", -thresh, "or >", thresh))
}


## Function for genes at receptor level and how they are connected within and between states
wntActiveModules <- function(corSepGI, corAcross, pState1=1, pState2=2, thresh=0.65, dthresh=0.5, vsize=5,
                             thCF=c(0,5), dthCF=c(0.2,0.8), xShift1=-2, yShift1=-16, xCo=1.5, xShift2=-5, yShift2=-10,
                             sn, snl, title="Wnt-active receptor level") {
  #define layout for destrcution complex (it is not connected to any other node on none of the states!!)
  goi = snl[[6]]
  allEdges = corSepGI[goi,goi,pState1] #baseline state
  tg = paste("b",rep(row.names(allEdges), times = dim(allEdges)[2]))
  qg = paste("b",rep(colnames(allEdges), each = dim(allEdges)[1]))
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  eDcB = selEdges
  gDcB <- graph.data.frame(eDcB, directed = FALSE)
  set.seed(214936)
  loDc <- layout.fruchterman.reingold(graph=gDcB,params=list(weights=abs(E(gDcB)$weight)))
  #define DC in induced state
  allEdges = corSepGI[goi,goi,pState2]
  tg = rep(row.names(allEdges), times = dim(allEdges)[2])
  qg = rep(colnames(allEdges), each = dim(allEdges)[1])
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  eDc = selEdges
  gDc <- graph.data.frame(eDc, directed = FALSE)
  
  #define baseline network for negative regulators
  goi=c(snl[[4]],snl[[5]])
  allEdges = corSepGI[goi,goi,pState1] #baseline state
  tg = paste("b",rep(row.names(allEdges), times = dim(allEdges)[2]))
  qg = paste("b",rep(colnames(allEdges), each = dim(allEdges)[1]))
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  eNrB = selEdges
  gNrB <- graph.data.frame(eNrB, directed = FALSE)
  #define layout for negative regulators in INDUCED state
  allEdges = corSepGI[goi,goi,pState2]
  tg = rep(row.names(allEdges), times = dim(allEdges)[2])
  qg = rep(colnames(allEdges), each = dim(allEdges)[1])
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  eNr = selEdges
  gNr <- graph.data.frame(eNr, directed = FALSE)
  gNr = add_vertices(gNr, nv = length(goi[-which(goi %in% V(gNr)$name)]), name=goi[-which(goi %in% V(gNr)$name)])
  set.seed(214936)
  loNr <- layout.fruchterman.reingold(graph=gNr,
                                      params=list(weights=abs(E(gNr)$weight)))
  
  #define baseline state main network connections (no layout)
  eG = which(sn %in% snl[[4]] | sn %in% snl[[5]] | sn %in% snl[[6]]) #indeces for genes excluded from layout
  allEdges = corSepGI[sn[-eG],sn[-eG],pState1]
  tg = paste("b",rep(row.names(allEdges), times = dim(allEdges)[2]))
  qg = paste("b",rep(colnames(allEdges), each = dim(allEdges)[1]))
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  eB = selEdges
  gB <- graph.data.frame(eB, directed = FALSE)
  #define layout for remaining nodes in induced state
  allEdges = corSepGI[sn[-eG],sn[-eG],pState2]
  tg = rep(row.names(allEdges), times = dim(allEdges)[2])
  qg = rep(colnames(allEdges), each = dim(allEdges)[1])
  dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
  selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
  selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
  selEdges = selEdges[which(selEdges[,3] < 1),]
  selEdges = selEdges[match(unique(selEdges[,3]), selEdges[,3]),]
  g <- graph.data.frame(selEdges, directed = FALSE)
  set.seed(114936)
  lo <- layout.fruchterman.reingold(graph=g,
                                    params=list(weights=abs(E(g)$weight)))
  lo[,1] = lo[,1]*3
  loDc[,1] = loDc[,1] + xShift1 #place next to each other
  loDc[,2] = loDc[,2] + yShift1
  loNr[,1] = loNr[,1] + xShift2 #place next to each other
  loNr[,2] = loNr[,2] + yShift2
  lotemp = rbind(lo, loNr, loDc) #merge layouts
  loM = rbind(lotemp, lotemp) #generate same layout for second state
  loM[1:dim(lotemp)[1],1] <- lotemp[,1] + sum(abs(range(lotemp[,1]))) + xCo # move it horizontally
  
  ##Add neg. reg. egdes in INDUCED state
  goi=c(snl[[4]],snl[[5]])
  g = add_vertices(g, nv = length(goi), name=V(gNr)$name)
  g = add.edges(g, edges = aperm(cbind(eNr[[1]], eNr[[2]]), c(2,1)),
                weight = eNr[[3]]) #width can also be indicated!!!
  ##Add DC egdes in INDUCED state
  g = add_vertices(g, nv = length(snl[[6]]), name=snl[[6]][c(6,1:5)])
  g = add.edges(g, edges = aperm(cbind(eDc[[1]], eDc[[2]]), c(2,1)),
                weight = eDc[[3]])
  
  #Add all other edges in baseline
  g = add_vertices(g, nv = length(sn[-eG]), name=paste("b",V(g)$name[1:length(sn[-eG])]))
  g = add.edges(g, edges = aperm(cbind(eB[[1]], eB[[2]]), c(2,1)),
                weight = eB[[3]])
  ##Add neg. reg. egdes in baseline state
  g = add_vertices(g, nv = length(goi), name=paste("b",V(gNr)$name)) # add order!!!!!!!!!!!!!!!!!!!
  g = add.edges(g, edges = aperm(cbind(eNrB[[1]], eNrB[[2]]), c(2,1)),
                weight = eNrB[[3]])
  ##Add DC egdes in baseline state
  g = add_vertices(g, nv = length(snl[[6]]), name=V(gDcB)$name)
  g = add.edges(g, edges = aperm(cbind(eDcB[[1]], eDcB[[2]]), c(2,1)),
                weight = eDcB[[3]])
  
  V(g)$size = vsize
  V(g)$label.cex = 0.6
  V(g)$label.color = "black"
  
  for(i in 1:length(V(g)$name)) {
    for(j in 1:length(snl)) {
      if(V(g)$name[i] %in% snl[[j]]) {
        V(g)$color[i] = snlCol[j]
        V(g)$frame.color[i] = snlCol[j]
      }
      if(V(g)$name[i] %in% snlB[[j]]) {
        V(g)$color[i] = snlCol[j]
        V(g)$frame.color[i] = snlCol[j]
      }
    }
  }
  ##add static relations in both states
  tg = paste("b", rep(sn[eG], times = length(sn[-eG]))) #baseline
  qg = paste("b", rep(sn[-eG], each = length(sn[eG])))
  snNW = corSepGI[sn[eG],sn[-eG],pState1]
  dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
  snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
  snNW = snNW[which(snNW[,3] > thresh | snNW[,3] < -thresh),]
  snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
  te = cbind(snNW[,1],snNW[,2])
  te = t(te)
  dim(te) = c(length(te),1)
  g = add.edges(g, te, weight = snNW[,3])
  
  tg = rep(sn[eG], times = length(sn[-eG])) #induced
  qg = rep(sn[-eG], each = length(sn[eG]))
  snNW = corSepGI[sn[eG],sn[-eG],pState2]
  dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
  snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
  snNW = snNW[which(snNW[,3] > thresh | snNW[,3] < -thresh),]
  snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
  te = cbind(snNW[,1],snNW[,2])
  te = t(te)
  dim(te) = c(length(te),1)
  g = add.edges(g, te, weight = snNW[,3])
  
  E(g)$width = (abs(E(g)$weight)-thresh+thCF[1])*thCF[2]
  
  #add dynamic relations across the states
  tg = paste("b", rep(sn, times = length(sn)))
  qg = rep(sn, each = length(sn))
  snNW = corAcross[sn,sn,pState1,pState2]
  snNW[upper.tri(snNW)] <- NA
  dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
  snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
  snNW = snNW[which(snNW[,3] > dthresh | snNW[,3] < -dthresh),]
  snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
  te = cbind(snNW[,1],snNW[,2])
  te = t(te)
  dim(te) = c(length(te),1)
  g = add.edges(g, te, weight = snNW[,3], width = (abs(snNW[,3])-dthresh+dthCF[1])*dthCF[2])
  
  E(g)$color <-  ifelse(E(g)$weight > 0, "#2680ff", "red")
  
  plot(g, layout = loM, main=title, sub=paste("Threshold: <", -thresh, "or >", thresh))
}



## High-confidence subnetwork of components connected to the ligand secretion and receptor binding machinery
wntReceptorLevelNw <- function(corSepGI, geneticBackground, sn, snl, snCol, thresh=0.65) {
  
  nw.par <- par(mfrow=c(1,2))
  
  for(matrixDim in 1:2) {
    allEdges = corSepGI[sn,sn,matrixDim]
    tg = rep(row.names(allEdges), times = dim(allEdges)[2])
    qg = rep(colnames(allEdges), each = dim(allEdges)[1])
    dim(allEdges) = c(dim(allEdges)[1]*dim(allEdges)[2],1)
    selEdges = data.frame(g1=tg, g2=qg, weight=allEdges, stringsAsFactors = FALSE)
    selEdges = selEdges[which(selEdges[,3] > thresh | selEdges[,3] < -thresh),]
    selEdges = selEdges[which(selEdges[,3] < 1),]
    selEdges = selEdges[order(selEdges[,3]),]
    selEdges = selEdges[seq(2,dim(selEdges)[1], by=2),]
    
    g <- graph.data.frame(selEdges, directed = FALSE)
    
    V(g)$size = 10
    V(g)$label.cex = 0.4
    V(g)$label.color = "black"
    E(g)$width = (abs(E(g)$weight)-thresh+0.1)*5    
    E(g)$color <-  ifelse(E(g)$weight > 0, "#2680ff", "red")
    
    for(i in 1:dim(selEdges)[1]) {
      for(j in 1:length(snCol)) {
        if(V(g)$name[i] %in% snl[[j]]) {
          V(g)$color[i] = snCol[j]
          V(g)$frame.color[i] = snCol[j]
        }
      }
    }
    
    set.seed(514936)
    lo <- layout.fruchterman.reingold(graph=g,
                                      params=list(weights=abs(E(g)$weight)))
    
    plot(g, layout = lo, main=geneticBackground[matrixDim], sub=paste("Threshold: <", -thresh, "or >", thresh))
  }
}


## Global high-confidence network w/o signed edges
wntNw <- function(corSepGI, geneticBackground, thresh = 0.65, sn) {
  tg = rep(row.names(corSepGI), times = dim(corSepGI)[1])
  qg = rep(row.names(corSepGI), each = dim(corSepGI)[1])
  
  
  nw.par <- par(mfrow=c(1,length(geneticBackground)))
  for(matrixDim in 1:length(geneticBackground)) {
    
    snNW = corSepGI[,,matrixDim]
    dim(snNW) = c(dim(snNW)[1]*dim(snNW)[2],1)
    snNW = data.frame(g1=tg, g2=qg, weight=snNW, stringsAsFactors = FALSE)
    snNW = snNW[which(snNW[,3] > thresh | snNW[,3] < -thresh),]
    snNW = snNW[which(snNW[,3] < 1),]
    snNW = snNW[order(snNW[,3]),]
    snNW = snNW[seq(2,dim(snNW)[1], by=2),]
    snNW = cbind(snNW, paste(snNW[,1], snNW[,2]))
    
    g = graph.empty(directed = FALSE)
    g = add.vertices(g, nv=dim(corSepGI)[1])
    V(g)$name = row.names(corSepGI)
    te = cbind(snNW[,1],snNW[,2])
    te = t(te)
    dim(te) = c(length(te),1)
    
    g = add.edges(g, te, weight = 1#snNW[,3]
                  , width = (abs(snNW[,3])-thresh)*0.8)
    E(g)$color <- "#525252"
    V(g)$frame.color <- ifelse(V(g)$name %in% sn, "#ffffff", "#969696") #if white background: selected verteces in "black"
    V(g)$color <- ifelse(V(g)$name %in% sn, "#ffffff", "#969696") #if white background: other verteces in "#bdbdbd"
    V(g)$size <- ifelse(V(g)$name %in% sn, 4, 3)
    V(g)$label.cex = 0.01
    V(g)$label.color = "black"
    
    set.seed(214936)
    lo <- layout.fruchterman.reingold(graph=g, dim = 3,
                                      params=list(weights=abs(E(g)$weight)))
    
    plot(g, layout = lo, main=geneticBackground[matrixDim], sub=paste("Threshold: <", -thresh, "or >", thresh))
  }
  
  par(nw.par)
}
