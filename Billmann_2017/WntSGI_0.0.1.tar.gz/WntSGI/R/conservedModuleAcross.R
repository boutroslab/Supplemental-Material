


conservedVSnonModules <- function(X1, X2, gb = geneticBackground, 
                                  states = 2:3, uth = 0.9, lth = 0.8) {
  par.ecdf <- par(mfrow = c(1,length(states)*2))
  for(i in states) {
    a = X1[,,1]
    diag(a) <- NA
    b = X1[,,i]
    diag(b) <- NA
    consMod = a > uth & b > uth
    nconsMod = (a > uth | b > uth) & (a < lth | b < lth)
    
    cM = 1-X2[,,1,i][consMod]
    ncM = 1-X2[,,1,i][nconsMod]
    selfGeneC = 1 - diag(X2[consModGene[,i-1],consModGene[,i-1],1,i])
    selfGene = 1 - diag(X2[,,1,i])
    cdat = list("Gene self"=selfGene,"Cons. mod. gene self"=selfGeneC, "Conserved module"=cM)
    ccol = c("black","#08306b","#6baed6")
    multiecdf(cdat, xlab="1 - between state similarity",
              main=gb[i], col=ccol, lwd=1.5,
              legend=list(x = "topleft", legend = names(cdat), fill = ccol, cex=0.5))
    #print(wilcox.test(cM, selfGeneC,alternative="less")[3])
    
    cdat = list("Gene self"=selfGene, "Non-conserved module"=ncM)
    ccol = c("black","#fd8d3c")
    multiecdf(cdat, xlab="1 - between state similarity",
              main=gb[i], col=ccol, lwd=1.5,
              legend=list(x = "topleft", legend = names(cdat), fill = ccol, cex=0.5))
    #print(wilcox.test(ncM, selfGene,alternative="greater")[3])
  }
  par(par.ecdf)
}

