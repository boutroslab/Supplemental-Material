
giHist <- function(singleKD, wntSignal, geneticInteractions, geneticBackground, ctrlMainEff,
                   cex.main=0.7, cex.lab=0.6, cex.axis=0.5, tck=-0.03, col="grey", border="darkgrey") {
  hist.par <- par(mfrow=c(3,length(geneticBackground)))
  for(i in 1:length(geneticBackground)) {
    hist(singleKD[-ctrlMainEff,i], breaks=50,
         main=paste("single knockdown effect",geneticBackground[i],sep="; "),
         xlim = range(singleKD[-ctrlMainEff,], na.rm=TRUE),
         xlab="log2 Wnt signaling activity", col=col, border=border, cex.main=cex.main, cex.lab=cex.lab, cex.axis=cex.axis, tck=tck)
    hist(wntSignal[-ctrlMainEff,,i], breaks=100,
         main=paste("co-RNAi effect",geneticBackground[i],sep="; "),
         xlim = range(wntSignal[-ctrlMainEff,,], na.rm=TRUE),
         xlab="log2 Wnt signaling activity", col=col, border=border, cex.main=cex.main, cex.lab=cex.lab, cex.axis=cex.axis, tck=tck)
    hist(geneticInteractions[,,i], breaks=100,
         main=paste("genetic interaction",geneticBackground[i],sep="; "),
         xlim = range(geneticInteractions, na.rm=TRUE),
         xlab="Pi score", col=col, border="black", cex.main=cex.main, cex.lab=cex.lab, cex.axis=cex.axis, tck=tck)
  }
  par(hist.par)
}


giDensity <- function(geneticInteractions, geneticBackground) {
  den.par <- par(mfrow=c(1,length(geneticBackground)))
  for(i in 1:length(geneticBackground)) {
    plot(density(geneticInteractions[,,i]), bty="n", main=geneticBackground[i],
         xlab="Genetic interaction [Pi score]", tck=-0.03, cex.axis=0.6, lwd=1.5)
  }
  par(den.par)
}



