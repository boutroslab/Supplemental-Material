


errorBars = function(x, y, sdev, col, lwd) {
  segments(x, y-sdev, x, y+sdev, col=col, lwd=lwd)
  segments(x-0.1, y-sdev, x+0.1, y-sdev, col=col, lwd=lwd)
  segments(x-0.1, y+sdev, x+0.1, y+sdev, col=col, lwd=lwd)
}


giBarplot <- function(goi, pState, 
                      singleKD, wntSignal, sdSingleKD, sdWntSignal, InteractionFDR,
                      space=0.8, cex.axis=0.4, cex.names=0.6, 
                      cex.lab=0.6, lwd=0.4, elwd=0.8) {
  bar.par <- par(mfrow=c(length(pState),length(goi$query)))
  for(j in pState) {
    gA = goi$template
    gB = goi$query
    for(i in 1:length(gA)) {
      ma = max(singleKD[c(gA[i],gB[i]),]+sdSingleKD[c(gA[i],gB[i]),],
               wntSignal[gA[i],gB[i],]+sdWntSignal[gA[i],gB[i],])
      mi = min(singleKD[c(gA[i],gB[i]),]-sdSingleKD[c(gA[i],gB[i]),],
               wntSignal[gA[i],gB[i],]-sdWntSignal[gA[i],gB[i],])
      a = singleKD[gA[i],j]
      b = singleKD[gB[i],j]
      d = wntSignal[gA[i],gB[i],j]
      x<-barplot(c(a, b, a+b, d),
                 col = c(ifelse(a > 0, "red", "darkgreen"),
                         ifelse(b > 0, "red", "darkgreen"),
                         "white",
                         ifelse(InteractionFDR[gA[i],gB[i],j],
                                ifelse(a+b > d, "blue","yellow"), "grey")),
                 ylab = "Wnt pathway activity", 
                 names.arg = c(gA[i], gB[i], paste(gA[i],"+",gB[i],"(exp.)"),
                               paste(gA[i],"+",gB[i],"(meas.)")),
                 border = c(NA, NA, "darkgrey",NA), space = space,
                 ylim=c(mi,ma),
                 las=2, tck=-0.03, cex.axis=cex.axis, 
                 cex.names=cex.names, cex.lab=cex.lab, lwd=lwd)
      abline(h=0, lwd=lwd)
      errorBars(x, y=c(a, b, a+b, d), 
                sdev=c(sdSingleKD[gA[i],j], sdSingleKD[gB[i],j], 0,
                       sdWntSignal[gA[i],gB[i],j]), 
                col=c(ifelse(a > 0, "red", "darkgreen"),
                      ifelse(b > 0, "red", "darkgreen"),
                      "darkgrey",
                      ifelse(InteractionFDR[gA[i],gB[i],j],
                             ifelse(a+b > d, "blue","yellow"), "grey")),
                lwd=elwd)
    }
  }
  par(bar.par)
}
