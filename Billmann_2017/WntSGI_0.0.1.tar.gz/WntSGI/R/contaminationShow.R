

contaminationShow <- function(d, e1, e2, b=rlDim, pw=passedWells) {
  plot(d[-c(e1,e2),1,b], d[-c(e1,e2),2,b]
       , cex=0.1, pch=16, main="Normalized Rluc values of each dsRNA"
       , ylab="query2 background",xlab="query1 background", bty="none", cex.main=0.8)
  points(d[c(e1,e2),1,b], d[c(e1,e2),2,b]
         , cex=0.2, pch=16, col="red")
  legend("topleft",c(paste(pw, "wells passed QC", sep=" ")
                     ,"potentially contaminated wells"),
         col=c("black","red"),pch=19,cex=0.4)
  abline(h=1,v=1,lty=2,lwd=0.5)
}

