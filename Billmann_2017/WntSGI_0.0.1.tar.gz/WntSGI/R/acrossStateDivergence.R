

acrossStateDivergence <- function(x1, x2, n, state = 2) {
  
  nCol = c("#f03b20","#fd8d3c","#fecc5c","#c2e699","#78c679","#31a354")
  
  par.dc <- par(mfrow = c(2, length(n)))
  for(j in 1:length(n)) {
    goi = n[j]
    
    vioplot(x1[goi,,1], x2[goi,,1,2], col="#f0f0f0",
            names = c("Baseline","Baseline to Wnt active"),
            drawRect=FALSE, border="#525252", wex=0.6)
    title(ylab=paste("PCC with ",goi))
    
    for(i in 1:length(n)) {lines(x=c(1,2), y=c(x1[goi,n,1][i], x2[goi,n,1,2][i]), col=nCol[i], lwd=2)}
    
    abline(h=c(0, 0.5, 0.65), lty=c(1,2,5), col="grey")
    textxy(X=rep(2, times=length(n)), Y=corAcross[goi,n,1,2], labs=n, cex=1.2, col=nCol)
  }
  
  for(j in 1:length(n)) {
    barplot((x1[n[j],n,1]-x2[n[j],n,1,2])/x1[n[j],n,1],
            col=nCol, ylab=paste("relative dPCC with ",n[j]), ylim=c(0,0.8), las=2)
  }
  par(par.dc)
}





