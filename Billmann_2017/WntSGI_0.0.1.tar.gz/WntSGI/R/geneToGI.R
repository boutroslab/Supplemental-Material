


geneToGI <- function(singleKD, geneticInteractions, geneticBackground, ctrlMainEff) {
  vs.par <- par(mfrow=c(length(geneticBackground),2))
  for(j in 1:length(geneticBackground)) {
    a = singleKD[-ctrlMainEff,j]
    b = geneticInteractions[order(a),,j]
    x = a[order(a)]
    
    plot(x, type="l", bty="n", ylim=c(-5,5), xlab="Selected genes",
         ylab="Adjusted amplitude of scores", cex.axis=0.6, cex.lab=0.6, tck=-0.02
         , lwd=3, main=geneticBackground[j])
    for(i in 1:dim(b)[2]) {
      points(b[,i], 
             col=ifelse(row.names(b) %in% c("sgg","Pten","Syx5","tow"),"darkred","darkgrey"),
             cex=0.2, pch=16)
    }
    
    y = apply(b, 1, var)
    scatter.smooth(x, y, cex=0.6, pch=16, span=0.3, xlab="single knockdown", cex.axis=0.6, cex.lab=0.6
                   , xlim=range(singleKD, na.rm=TRUE)
                   , ylab="Variance Pi-scores", main=geneticBackground[j])
  }
  par(vs.par)
}
