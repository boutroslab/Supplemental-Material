

giToState <- function(geneticInteractions, gi, wntReceptor, destructionComplex, indReg, wntTF,
                      allcex=0.3, pcex=0.6, lcex=0.5) {
  tg = rep(row.names(geneticInteractions), times = dim(geneticInteractions)[2])
  qg = rep(colnames(geneticInteractions), each = dim(geneticInteractions)[1])
  pc = list(col=rep(NA, times=prod(dim(geneticInteractions)[1:2])),
            pch=rep(NA, times=prod(dim(geneticInteractions)[1:2])))
  
  pcF = list(col=c("#31a354", "#88419d", "#8c6bb1", "#8c96c6"), pch=c(19, 15, 19, 17))
  for(i in 1:length(pc[[1]])) {
    for(j in 1:2) {
      if(tg[i] %in% wntReceptor & qg[i] %in% wntTF) {
        pc[[j]][i] = pcF[[j]][2]
      } else if(tg[i] %in% destructionComplex & qg[i] %in% wntTF) {
        pc[[j]][i] = pcF[[j]][3]
      } else if(tg[i] %in% wntTF & qg[i] %in% wntTF) {
        pc[[j]][i] = pcF[[j]][1]
      } else if(tg[i] %in% wntTF & qg[i] %in% destructionComplex) {
        pc[[j]][i] = pcF[[j]][3]
      } else if(tg[i] %in% wntTF & qg[i] %in% wntReceptor) {
        pc[[j]][i] = pcF[[j]][2]
      } else if(tg[i] %in% indReg & qg[i] %in% wntTF) {
        pc[[j]][i] = pcF[[j]][4]
      } else if(tg[i] %in% wntTF & qg[i] %in% indReg) {
        pc[[j]][i] = pcF[[j]][4]
      }
    }
  }
  
  gi.par <- par(mfrow=c(1,2))
  for(i in 2:3) {
    plot(gi[,1], gi[,i], cex=allcex, ylim=range(gi[,2:3]), col="#525252", pch=16,
         xlab="Baseline state [Pi score]",
         ylab = ifelse(i == 2, "Ligand-induced [Pi score]","Apc LoF-induced [Pi score]"),
         main=paste("r:",cor(gi[,1],gi[,i], use = "complete.obs")))
    abline(h=0, v=0, lty=2)
    points(gi[,1], gi[,i], cex=pcex, col=pc$col, pch=pc$pch)
    legend("topleft",c("all interactions","between wnt TFs","wnt TFs & receptors",
                       "wnt TFs & feedback","wnt TFs & destruction complex"),
           col=c("#525252",pcF$col), pch=c(16, pcF$pch), bty="n", cex=lcex)
  }
  par(gi.par)
}
