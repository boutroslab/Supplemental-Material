



acrossHist <- function(x, gb = geneticBackground, states=2:3) {
  par.gi <- par(mfrow = c(1,length(states)*2))
  for(i in states) {
    a = x[,,1,i]
    diag(a) <- NA
    hist(a, xlim=c(-1,1), breaks=50, main=gb[i], xlab="PCC between genes", border="darkgrey")
    abline(v=c(-0.5,0.5), lty=2)
    
    rug(diag(x[,,1,i]),col="black")
    hist(diag(x[,,1,i]), xlim=c(-1,1),
         breaks=30, main=gb[i], xlab="PCC between genes", border="grey", col="black")
  }
  par(par.gi)
}



acrossHistExample <- function(x, states, pPair, nPair, gb=geneticBackground) {
  for(i in states) {
    a = x[,,1,i]
    diag(a) <- NA
    hist(a, xlim=c(-1,1),breaks=50, main=paste("to",gb[i]),
         xlab="PCC between genes", border="darkgrey")
    abline(v=c(-0.5,0.5), lty=2)
    abline(v=x[pPair[1],pPair[2],1,i], col="#2680ff")
    abline(v=x[nPair[1],nPair[2],1,i], col="red")
  }
}



selfOthersAcross <- function(X, states, gb = geneticBackground) {
  par.ecdf <- par(mfrow = c(1,length(states)))
  for(i in states) {
    inC = 1-X[,,1,i]
    diag(inC) <- NA
    
    outC = 1 - diag(X[,,1,i])
    multiecdf(list("In complex"=inC, "Outside complex"=outC), xlab="1 - PCC"
              , main=gb[i], col=c("darkgrey","black"), lwd=2
              , legend=FALSE)
    print(gb[i])
    print(wilcox.test(inC,outC,alternative="greater")[3])
  }
  par(par.ecdf)
}



acrossHistCore <- function(x1, thresh=0.5, a=sn,
                           states = 2, gb=geneticBackground) {
  for(i in states) {
    snDat = x1[a,a,1,i]
    
    snDatP = snDat[snDat > thresh]
    snDatN = snDat[snDat < -thresh]
    
    hist(x1[,,1,i], xlim=c(-1,1),
         breaks=50, main=paste("to",gb[i]), xlab="PCC between genes", border="darkgrey")
    abline(v=c(-0.5,0.5), lty=2)
    abline(v=snDatP, col="#2680ff")
    abline(v=snDatN, col="red")
  }
}



