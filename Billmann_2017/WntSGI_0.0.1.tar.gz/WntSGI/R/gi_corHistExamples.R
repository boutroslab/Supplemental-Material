


histStateExamples <- function(x, thresh = 0.65, pPair, nPair, gb = geneticBackground) {
  par.gi <- par(mfrow = c(1,3))
  for(i in 1:length(gb)) {
    hist(x[,,i][lower.tri(x[,,i],diag = FALSE)], xlim=c(-1,1),
         breaks=50, main=gb[i], xlab="PCC between genes", border="darkgrey")
    abline(v=c(-thresh,thresh), lty=2)
    
    for(j in 1:length(pPair)) {
      abline(v=x[pPair[[j]][1],pPair[[j]][2],i], col="#2680ff")
    }
    for(j in 1:length(nPair)) {
      abline(v=x[nPair[[j]][1],nPair[[j]][2],i], col="red")
    }
  }
  par(par.gi)
}




histStateCore <- function(x, thresh = 0.65, a=sn, gb = geneticBackground) {
  par.gi <- par(mfrow = c(1,3))
  for(i in 1:length(gb)) {
    hist(x[,,i][lower.tri(x[,,i],diag = FALSE)], xlim=c(-1,1),
         breaks=50, main=gb[i], xlab="PCC between genes", border="darkgrey")
    abline(v=c(-thresh,thresh), lty=2)
    
    snDat = x[a,a,i]
    snDat[upper.tri(snDat, diag = TRUE)] <- NA
    snDatP = snDat[which(snDat > thresh)]
    snDatN = snDat[which(snDat < -thresh)]
    abline(v=snDatP, col="#2680ff")
    abline(v=snDatN, col="red")
  }
  par(par.gi)
}



