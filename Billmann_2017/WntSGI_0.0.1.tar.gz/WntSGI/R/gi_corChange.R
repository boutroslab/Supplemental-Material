


geneChangeCor <- function(x, a, b, cf = c(2.5,1.5,2,2,5)) {
  par.gi <- par(mfrow = c(1,5))
  for(i in 1:length(a)) {
    plot(c(x[a[i],,1],x[a[i],,2]+cf[i]),
         c(x[b[i],,1],x[b[i],,2]), pch=16,
         xlab=a[i], ylab=b[i])
    segments(x[a[i],,1], x[b[i],,1],
             x[a[i],,2]+cf[i], x[b[i],,2], col="grey")
  }
  par(par.gi)
}




geneChangeAcross <- function(x, a, b, states) {
  ab=unique(c(a,b))
  par.gi <- par(mfrow = c(2,5))
  for(i in 1:length(ab)) {
    plot(x[ab[i],,states], main=ab[i], pch=16)
  }
  par(par.gi)
}



