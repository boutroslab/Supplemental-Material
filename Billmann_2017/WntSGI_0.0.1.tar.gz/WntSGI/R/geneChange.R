


geneChange <- function(X1, X2, X3, states = 2:3) {
  par.gi <- par(mfrow = c(1,length(states)))
  for(i in states) {
    colkey = colorRampPalette(c("darkgreen","white","darkred"))(336)
    meO = order(X1[-which(row.names(X1) =="GFP"),i])
    
    a = X2[,,i]
    diag(a) <- NA
    b <- apply(abs(a), 2, max, na.rm=TRUE)
    d = diag(X3[,,1,i])
    
    plot(d[meO], b[meO], col=colkey, pch=16, cex=b[meO]/((0.5+(abs(min(d))+d))[meO])*1.2,
         xlab="Self-correlation [PCC]", ylab="Max. similarity after activation",
         main=paste("to", geneticBackground[i]))
    textxy(diag(X3[,,1,i])[meO], b[meO], labs=names(b)[meO])
  }
  par(par.gi)
}



