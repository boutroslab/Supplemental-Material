

plotCumuRank <- function(a, thGene="sgg", gb=geneticBackground[j],
                         coMain=ifelse(i==2 & j>1, "to", "in")) {
  pcol = rep("grey",times=length(cn))
  pcol[cn %in% sCl] <- "red"
  
  plot(sort(a), pch=1, col=pcol[order(a)], main=paste(coMain, gb), cex=0.8,
       xlab="No. genes", ylab="Cumulative rank distance, destruction complex", bty="n")
  zl = max(c(length(which(a <= a[thGene])), 30))
  abline(v=zl, lty=2)
  plot(sort(a)[1:zl], pch=16, col=pcol[order(a)][1:zl], main="zoom", cex=1.5,
       xlab="No. genes", ylab="Cumulative rank distance, destruction complex")
  textxy(X=1:zl, Y=sort(a)[1:zl], labs=names(a)[order(a)][1:zl])
}




dcDistancePheno <- function(a, Y1, Y2, yl = range(singleKD[,1:2])) {
  
  colkey = colorRampPalette(c("darkgreen","white","darkred"))(336)
  
  Y12 = Y2-Y1
  
  y1O = order(Y1)
  y2O = order(Y2)
  y12O = order(Y12)
  plot(a[y12O], Y1[y12O], col=colkey, pch=16, cex=0.6, ylim=yl, xlab="cum. dist. DC", ylab="Rel. Wnt activity")
  points(a[y12O], Y2[y12O], col=colkey, pch=16, cex=0.8)
  segments(y0 = Y1[y12O], y1 = Y2[y12O], x0=a[y12O], x1=a[y12O], col=colkey)
  #textxy(X = a[y2O], Y = Y2[y2O], labs=cn[y2O])
}
