

giProfileCor <- function(x, gene1, gene2, states, pcex=0.4) {
  a = "Genetic interactions"
  
  gi.par <- par(mfrow=c(1,length(states)))
  for(i in 1:length(states)) {
    plot(x[gene1,,states[i]], x[gene2,,states[i]], bty='none',
         xlab=paste(a, gene1), ylab=paste(a, gene2), pch=16, cex=pcex, cex.lab=0.5, cex.axis=0.5,
         xlim=range(x[gene1,,states], na.rm=TRUE),
         ylim=range(x[gene2,,states], na.rm=TRUE),
         main=paste("r:", substr(cor(x[gene1,,states[i]], x[gene2,,states[i]]), 1, 5)))
  }
  par(gi.par)
}




giAcrossProfileCor <- function(x, gene1, gene2, states=1:2, pcex=0.5) {
  a = "Genetic interactions"
  
  plot(x[gene1,,states[1]], x[gene2,,states[2]], bty='none',
       xlab=paste(a, gene1), ylab=paste(a, gene2), pch=16, cex=pcex, cex.lab=0.5, cex.axis=0.5,
       xlim=range(x[gene1,,states], na.rm=TRUE),
       ylim=range(x[gene2,,states], na.rm=TRUE),
       main=paste("r:", substr(cor(x[gene1,,states[1]],x[gene2,,states[2]]), 1, 5)))
}


