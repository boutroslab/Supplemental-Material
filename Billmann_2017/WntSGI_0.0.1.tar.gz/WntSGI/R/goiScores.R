


relWntGOI <- function(x1, x2, states, goi, yl=c(-0.5,0.5),
                      gb=geneticBackground) {
  par.bar <- par(mfrow = c(1,length(states)))
  for(i in states) {
    ## Get non-T control effect that represents the median of all GFP ctrls
    ctrlEff = sort(x2[which(row.names(x1)=="GFP"),i])[[9]]
    ## Get its bootstrapped SD
    ctrlErr = x2[which(row.names(x1)=="GFP")[which(order(x1[which(row.names(x1)=="GFP"),i]) == 9)],i]
    
    a = c(ctrlEff, x1[goi,i])
    b = c(ctrlErr, x2[goi,i])
    x <- barplot(a, ylim=yl, ylab="Rel. Wnt activity", main=gb[i],
                 names.arg = c("ctrl", goi), las=2)
    abline(h=0)
    segments(x0 = x, y0 = a-b, y1 = a+b)
  }
  par(par.bar)
}






giGOIpartners <- function(x1, x2, goi, partners, states,
                          yl=c(-0.2,0.6), gb=geneticBackground) {
  for(i in states) {
    a = geneticInteractions[goi,partners,i]
    b = giSD[goi,partners,i]
    x <- barplot(a, ylim=yl, ylab=paste("Genetic interaction with", goi),
                 main = gb[i])
    abline(h=0)
    segments(x0 = x, y0 = a-b, y1 = a+b)
  }
}


